﻿namespace maisAgua.Domain.Enumerators
{
    public enum SensorTypes
    {
        ESP32 = 1
    }
}
